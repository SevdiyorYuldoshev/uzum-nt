package uz.nt.uzumnt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UzumNtApplication {

    public static void main(String[] args) {
        SpringApplication.run(UzumNtApplication.class, args);
    }

}
